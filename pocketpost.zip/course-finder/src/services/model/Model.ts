export interface CourseEntry {
    id: string,
    course_name: string,
    course_code: string,
    photoUrl?: string
}